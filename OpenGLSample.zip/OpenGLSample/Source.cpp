﻿#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <SOIL2.h>

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Textures
GLuint caseTexture;
GLuint tableTexture;
GLuint bowlTexture;
GLuint roundPumpkinTexture;
GLuint pumpkinStemTexture;
GLuint woodPumpkinTexture;

// the cameras coordinates and speed
float radius = 10.0;
float camX = 0;
float camY = 2;
float camZ = 5.0;
float camSpeed = 0.01;

// variable to toggle perspective and orthographic view
int display = 0;

// the target location that the camera is looking at
float targetX = 0.0;
float targetY = 0.0;

// Detects initial mouse movement
bool firstMouseMove = true;

// initial variables for the last x and y coordinates and the change in them from last to current locations
float lastX = 400, lastY = 300, xChange, yChange;

// function stubs for mouse and scroll wheel movement
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);

// Light source positions
glm::vec3 lightPosition(0.0f, 2.0f, 3.0f);
glm::vec3 lightPosition2(0.0f, 1.0f, -2.0f);


// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Mod 7-Project"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];     // Handles for the vertex buffer objects
        GLuint nIndices;    // Number of indices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;

    // Triangle mesh data
    GLMesh gMesh;
    GLMesh gMesh2;
    GLMesh gMesh3;
    GLMesh gMesh4;
    GLMesh gMesh5;
    GLMesh gMesh6;
    GLMesh gMesh7;
    GLMesh gMesh8;

    // Shader program
    GLuint gProgramId;
    GLuint gProgramId2;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UCreateMesh(GLMesh& mesh, GLMesh& mesh2, GLMesh& mesh3, GLMesh& mesh4, GLMesh& mesh5, GLMesh& mesh6, GLMesh& mesh7, GLMesh& mesh8);
void UDestroyMesh(GLMesh& mesh, GLMesh& mesh2, GLMesh& mesh3, GLMesh& mesh4, GLMesh& mesh5, GLMesh& mesh6, GLMesh& mesh7, GLMesh& mesh8);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,
layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
layout(location = 1) in vec4 color;  // Color data from Vertex Attrib Pointer 1
layout(location = 2) in vec2 texture;  // Texture data from Vertex Attrib Pointer 2
layout(location = 3) in vec3 normal;  // Normal data from Vertex Attrib Pointer 3

out vec4 vertexColor; // variable to transfer color data to the fragment shader
out vec2 vertexTexture; // variable to transfer texture data to the fragment shader
out vec3 vertexNormal; // variable to transfer normal data to the fragment shader
out vec3 fragPos; // variable to position data to the fragment shader

//Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
    vertexColor = color; // references incoming color data
    vertexTexture = texture; // references incoming texture data
    vertexNormal = mat3(transpose(inverse(model))) * normal;
    fragPos = vec3(model * vec4(position, 1.0f));
}
);


/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,
in vec4 vertexColor; // Variable to hold incoming color data from vertex shader
in vec2 vertexTexture; // Variable to hold incoming texture data from vertex shader
in vec3 vertexNormal; // Variable to hold incoming normal data from vertex shader
in vec3 fragPos;

out vec4 fragmentColor;
uniform sampler2D myTexture;
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightColor2;
uniform vec3 lightPos;
uniform vec3 lightPos2;
uniform vec3 viewPos;

void main()
{
    // vertex normals and angle to fragment
    vec3 norm = normalize(vertexNormal);
    vec3 viewDir = normalize(viewPos - fragPos);

    // Ambient
    float ambientStrength = 0.2f;
    vec3 ambient = ambientStrength * lightColor;

    // Diffuse
    vec3 lightDir = normalize(lightPos - fragPos);
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = diff * lightColor;

    // Specularity
    float specularStrength = 1.0f;
    vec3 reflectDir = reflect(-lightDir, norm);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), 128);
    vec3 specular = specularStrength * spec * lightColor;

    // Ambient2
    float ambientStrength2 = 0.2f;
    vec3 ambient2 = ambientStrength2 * lightColor2;

    // Diffuse2
    vec3 lightDir2 = normalize(lightPos2 - fragPos);
    float diff2 = max(dot(norm, lightDir2), 0.0);
    vec3 diffuse2 = (diff2 * 0.5) * lightColor2;

    // Specularity2
    float specularStrength2 = 1.0f;
    vec3 reflectDir2 = reflect(-lightDir2, norm);
    float spec2 = pow(max(dot(viewDir, reflectDir2), 0.0), 128);
    vec3 specular2 = specularStrength2 * spec2 * lightColor2;

    vec3 result = (ambient + ambient2 + diffuse + diffuse2 + specular + specular2) * objectColor;
    fragmentColor = texture(myTexture, vertexTexture) * vec4(result, 1.0f);
}
);

// Lamp Vertex Shader Source Code //
const GLchar* lampVertexShaderSource = GLSL(440,
layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0

//Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
}
);

/* Lamp fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

out vec4 fragmentColor;

void main()
{
    fragmentColor = vec4(1.0f);
}
);


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateMesh(gMesh, gMesh2, gMesh3, gMesh4, gMesh5, gMesh6, gMesh7, gMesh8); // Calls the function to create the Vertex Buffer Object

    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    // Create the lamp shader program
    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gProgramId2))
        return EXIT_FAILURE;

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();

    }

    // Release mesh data
    UDestroyMesh(gMesh, gMesh2, gMesh3, gMesh4, gMesh5, gMesh6, gMesh7, gMesh8);

    // Release shader program
    UDestroyShaderProgram(gProgramId);

    // Release shader program
    UDestroyShaderProgram(gProgramId2);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);



    // captures the cursor in the window and passes it to the function / makes the cursor non-visible
    glfwSetCursorPosCallback(*window, mouse_callback);
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // captures scroll wheel movement in the window and passes it to the functione
    glfwSetScrollCallback(*window, scroll_callback);


    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    // if escape is pressed the window is set to close
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    // if the s key is pressed the camera appears to move back
    else if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camZ += camSpeed;

    // if the w key is pressed the camera appears to move forward
    else if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camZ -= camSpeed;

    // if the a key is pressed the camera appears to move to the right
    else if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camX -= camSpeed;

    // if the d key is pressed the camera appears to move to the left
    else if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camX += camSpeed;

    // if the q key is pressed the camera appears up
    else if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        camY += camSpeed;

    // if the e key is pressed the camera appears to move down
    else if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        camY -= camSpeed;

    // if the p key is pressed the display variable switches to toggle between perspective and orthographic
    else if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
    {
        if (display == 0)
        {
            display = 1;
        }
        else if (display == 1)
        {
            display = 0;
        }
    }

    // if the f key is pressed the camera appears to reset
    else if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS)
    {
        camX = 0;
        camY = 2;
        camZ = 5.0;
        targetX = 0.0;
        targetY = 0.0;
    }
}


void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    // if the scroll wheel is moved then it speeds or slows the camera speed while Clamping it between 0.01 and 1.0
    if (camSpeed >= 0.001 && camSpeed <= 1.5)
        camSpeed += yoffset * 0.01;

    // Default camSpeed
    if (camSpeed < 0.001)
        camSpeed = 0.001;
    if (camSpeed > 1.5)
        camSpeed = 1.5;
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    // detects the first mouse move and sets the last x and y coordinates to the current cursor location
    if (firstMouseMove)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouseMove = false;
    }

    // Calculate the cursor offset
    xChange = xpos - lastX;
    yChange = lastY - ypos;

    lastX = xpos;
    lastY = ypos;

    targetX += xChange * camSpeed;
    targetY -= yChange * camSpeed;

}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// Functioned called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 1.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // 1. Scales the object by 1
    glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    // 2. Rotates shape by 0 degrees on the y axis
    glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
    // 3. Place object at the origin
    glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = translation * rotation * scale;

    // Transforms the camera: move the camera back (z axis)
    glm::mat4 view = glm::translate(glm::vec3(0.0f, 2.0f, 5.0f));

    // feeds the camera location, the target location, and the worlds up into the lookat function to create the view
    view = glm::lookAt(glm::vec3(camX, camY, camZ), glm::vec3(targetX, targetY, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));

    //// if the display variable is 0 then the projection will change to perspective
    if (display == 0)
    {
        glm::mat4 projection = glm::perspective(45.0f, (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

        // Set the shader to be used
        glUseProgram(gProgramId);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc = glGetUniformLocation(gProgramId, "model");
        GLint viewLoc = glGetUniformLocation(gProgramId, "view");
        GLint projLoc = glGetUniformLocation(gProgramId, "projection");

        // Get light color, object color, light, and view location
        GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
        GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
        GLint lightColorLoc2 = glGetUniformLocation(gProgramId, "lightColor2");
        GLint lightPosLoc = glGetUniformLocation(gProgramId, "lightPos");
        GLint lightPosLoc2 = glGetUniformLocation(gProgramId, "lightPos2");
        GLint viewPosLoc = glGetUniformLocation(gProgramId, "viewPos");

        // Assign light and object colors
        glUniform3f(objectColorLoc, 1.0f, 1.0f, 1.0f);
        glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
        glUniform3f(lightColorLoc2, 0.92f, 0.86f, 0.20f);

        // Set light position
        glUniform3f(lightPosLoc, lightPosition.x, lightPosition.y, lightPosition.z);
        glUniform3f(lightPosLoc2, lightPosition2.x, lightPosition2.y, lightPosition2.z);

        // Specify view position
        glUniform3f(viewPosLoc, camX, camY, camZ);

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

        // Binds the case texture
        glBindTexture(GL_TEXTURE_2D, caseTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Unbinds the case texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the table texture
        glBindTexture(GL_TEXTURE_2D, tableTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh2.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh2.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the table texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the bowl texture
        glBindTexture(GL_TEXTURE_2D, bowlTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh4.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh4.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the round pumpkin texture
        glBindTexture(GL_TEXTURE_2D, roundPumpkinTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh5.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh5.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the pumpkin stem texture
        glBindTexture(GL_TEXTURE_2D, pumpkinStemTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh6.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh6.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the wood pumpkin texture
        glBindTexture(GL_TEXTURE_2D, woodPumpkinTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh7.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh7.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the pumpkin stem texture
        glBindTexture(GL_TEXTURE_2D, pumpkinStemTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh8.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh8.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the texture
        glBindTexture(GL_TEXTURE_2D, 0);

        glUseProgram(gProgramId2);

        // Retrieves and passes transform matrices to the Shader program
        GLint lampModelLoc = glGetUniformLocation(gProgramId2, "model");
        GLint lampViewLoc = glGetUniformLocation(gProgramId2, "view");
        GLint lampProjLoc = glGetUniformLocation(gProgramId2, "projection");

        glUniformMatrix4fv(lampModelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(lampViewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(lampProjLoc, 1, GL_FALSE, glm::value_ptr(projection));

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh3.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh3.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        glUseProgram(0);
    }
    // if the display variable is 1 then the projection will change to orthographic
    else if (display == 1)
    {
        glm::mat4 projection = glm::ortho(-20.0f, 20.0f, -20.0f, 20.0f, -20.0f, 20.0f);

        // Set the shader to be used
        glUseProgram(gProgramId);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc = glGetUniformLocation(gProgramId, "model");
        GLint viewLoc = glGetUniformLocation(gProgramId, "view");
        GLint projLoc = glGetUniformLocation(gProgramId, "projection");

        // Get light color, object color, light, and view location
        GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
        GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
        GLint lightColorLoc2 = glGetUniformLocation(gProgramId, "lightColor2");
        GLint lightPosLoc = glGetUniformLocation(gProgramId, "lightPos");
        GLint lightPosLoc2 = glGetUniformLocation(gProgramId, "lightPos2");
        GLint viewPosLoc = glGetUniformLocation(gProgramId, "viewPos");

        // Assign light and object colors
        glUniform3f(objectColorLoc, 1.0f, 1.0f, 1.0f);
        glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);
        glUniform3f(lightColorLoc2, 1.0f, 1.0f, 1.0f);

        // Set light position
        glUniform3f(lightPosLoc, lightPosition.x, lightPosition.y, lightPosition.z);
        glUniform3f(lightPosLoc2, lightPosition2.x, lightPosition2.y, lightPosition2.z);

        // Specify view position
        glUniform3f(viewPosLoc, camX, camY, camZ);

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

        // Binds the case texture
        glBindTexture(GL_TEXTURE_2D, caseTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Unbinds the case texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the table texture
        glBindTexture(GL_TEXTURE_2D, tableTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh2.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh2.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the table texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the bowl texture
        glBindTexture(GL_TEXTURE_2D, bowlTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh4.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh4.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the round pumpkin texture
        glBindTexture(GL_TEXTURE_2D, roundPumpkinTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh5.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh5.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the pumpkin stem texture
        glBindTexture(GL_TEXTURE_2D, pumpkinStemTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh6.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh6.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the wood pumpkin texture
        glBindTexture(GL_TEXTURE_2D, woodPumpkinTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh7.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh7.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the texture
        glBindTexture(GL_TEXTURE_2D, 0);

        // Binds the pumpkin stem texture
        glBindTexture(GL_TEXTURE_2D, pumpkinStemTexture);

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh8.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh8.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        // Uninds the texture
        glBindTexture(GL_TEXTURE_2D, 0);

        glUseProgram(gProgramId2);

        // Retrieves and passes transform matrices to the Shader program
        GLint lampModelLoc = glGetUniformLocation(gProgramId2, "model");
        GLint lampViewLoc = glGetUniformLocation(gProgramId2, "view");
        GLint lampProjLoc = glGetUniformLocation(gProgramId2, "projection");

        glUniformMatrix4fv(lampModelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(lampViewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(lampProjLoc, 1, GL_FALSE, glm::value_ptr(projection));

        // Activate the VBOs contained within the mesh's VAO
        glBindVertexArray(gMesh3.vao);

        // Draws the triangles
        glDrawElements(GL_TRIANGLES, gMesh3.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

        // Deactivate the Vertex Array Object
        glBindVertexArray(0);

        glUseProgram(0);
    }

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


// Implements the UCreateMesh function
void UCreateMesh(GLMesh& mesh, GLMesh& mesh2, GLMesh& mesh3, GLMesh& mesh4, GLMesh& mesh5, GLMesh& mesh6, GLMesh& mesh7, GLMesh& mesh8)
{

    // Glasses case vertices
    GLfloat verts[] = {

        // Triangle 1
        0.25f, -0.5f, -0.25f, // right back base vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, -1.0f, 0.0f, // Normal negative y

       -0.25f,  -0.5f, -0.25f, // left back base vertex 1
        0.0f, 1.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, -1.0f, 0.0f, // Normal negative y

        0.0f, -0.5f,  0.25f, // middle base vertex 2
        0.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
        0.5f, 1.0f, // UV
        0.0f, -1.0f, 0.0f, // Normal negative y

        // Triangle 2
        0.25f,  0.5f, -0.25f, // right back top vertex 3
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

       -0.25f,  0.5f, -0.25f, // left back top vertex 4
        0.0f, 1.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        0.0f,   0.5f,  0.25f, // middle top vertex 5
        0.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
        0.5f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 3
        -0.25f,  -0.5f, -0.25f, // left back base vertex 6
         0.0f, 1.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x positive z

         0.0f,   -0.5f,  0.25f, // middle base vertex 7
         0.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x positive z

       -0.25f,  0.5f, -0.25f, // left back top vertex 8
        0.0f, 1.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, 1.0f, // Normal negative x positive z

        // Triangle 4
        0.0f,   -0.5f,  0.25f, // middle base vertex 9
        0.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 0.0f, 1.0f, // Normal negative x positive z

       -0.25f,  0.5f, -0.25f, // left back top vertex 10
        0.0f, 1.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, 1.0f, // Normal negative x positive z

        0.0f,   0.5f,  0.25f, // middle top vertex 11
        0.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
       -1.0f, 0.0f, 1.0f, // Normal negative x positive z

        // Triangle 5
        0.25f,  -0.5f, -0.25f, // right back base vertex 12
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x positive z

        0.0f,   -0.5f,  0.25f, // middle base vertex 13
        0.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x positive z

        0.25f,  0.5f, -0.25f, // right back top vertex 14
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x positive z

        // Triangle 6
        0.0f,   -0.5f,  0.25f, // middle base vertex 15
        0.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x positive z

        0.25f,  0.5f, -0.25f, // right back top vertex 16
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x positive z

        0.0f,   0.5f,  0.25f, // middle top vertex 17
        0.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x positive z

        // Triangle 7
        0.25f,  -0.5f, -0.25f, // right back base vertex 18
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

       -0.25f,  -0.5f, -0.25f, // left back base vertex 19
        0.0f, 1.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

        0.25f,  0.5f, -0.25f, // right back top vertex 20
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

        // Triangle 8
       -0.25f,  -0.5f, -0.25f, // left back base vertex 21
        0.0f, 1.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

        0.25f,  0.5f, -0.25f, // right back top vertex 22
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

       -0.25f,  0.5f, -0.25f, // left back top vertex 23
        0.0f, 1.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

        // Triangle 9
        -6.0f,  -0.5f, -3.0f, // forward left vertex 24
         1.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y

         6.0f,  -0.5f, -3.0f, // forward right vertex 25
         1.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y

         6.0f,  -0.5f,  3.0f, // rear right vertex 26
         1.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 1.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 10
         6.0f,  -0.5f,  3.0f, // rear right vertex 27
         1.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 1.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y

        -6.0f,  -0.5f,  3.0f, // rear left vertex 28
         1.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y

        -6.0f,  -0.5f, -3.0f, // forward left vertex 29
         1.0f, 0.0f, 1.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y

    };

    // Glasses case indices
    GLushort indices[] = {

        // Glasses case base
        0, 1, 2, // Triangle 1

        // Glasses case top
        3, 4, 5, // Triangle 2

        // Glasses case plane 1
        6, 7, 8, // Triangle 3
        9, 10, 11, // Triangle 4

        // Glasses case plane 2
        12, 13, 14, // Triangle 5
        15, 16, 17, // Triangle 6

        // Glasses case plane 3
        18, 19, 20, // Triangle 7
        21, 22, 23, // Triangle 8
    };

    // Table indices
    GLushort indices2[] = {

        // table plane
        24, 25, 26, // Triangle 9
        27, 28, 29, // Triangle 10
    };

    // Light source vertices
    GLfloat verts2[] = {

        // Light source 1 //

        // Triangle 1
        lightPosition.x + 0.1f,  lightPosition.y + 0.1f, lightPosition.z - 0.1f, // Light vertex 0

        lightPosition.x + 0.1f,  lightPosition.y + 0.1f, lightPosition.z + 0.1f, // Light vertex 1

        lightPosition.x - 0.1f,  lightPosition.y + 0.1f, lightPosition.z + 0.1f, // Light vertex 2

        // Triangle 2
        lightPosition.x + 0.1f,  lightPosition.y + 0.1f, lightPosition.z - 0.1f, // Light vertex 3

        lightPosition.x - 0.1f,  lightPosition.y + 0.1f, lightPosition.z - 0.1f, // Light vertex 4

        lightPosition.x - 0.1f,  lightPosition.y + 0.1f, lightPosition.z + 0.1f, // Light vertex 5

        // Triangle 3
        lightPosition.x + 0.1f, lightPosition.y - 0.1f, lightPosition.z - 0.1f, // Light vertex 6

        lightPosition.x + 0.1f, lightPosition.y - 0.1f, lightPosition.z + 0.1f, // Light vertex 7

        lightPosition.x - 0.1f, lightPosition.y - 0.1f, lightPosition.z + 0.1f, // Light vertex 8

        // Triangle 4
        lightPosition.x + 0.1f, lightPosition.y - 0.1f, lightPosition.z - 0.1f, // Light vertex 9

        lightPosition.x - 0.1f, lightPosition.y - 0.1f, lightPosition.z - 0.1f, // Light vertex 10

        lightPosition.x - 0.1f, lightPosition.y - 0.1f, lightPosition.z + 0.1f, // Light vertex 11

        // Triangle 5
        lightPosition.x + 0.1f, lightPosition.y + 0.1f, lightPosition.z - 0.1f, // Light vertex 12

        lightPosition.x + 0.1f, lightPosition.y - 0.1f, lightPosition.z - 0.1f, // Light vertex 13

        lightPosition.x + 0.1f, lightPosition.y - 0.1f, lightPosition.z + 0.1f, // Light vertex 14

        // Triangle 6 
        lightPosition.x + 0.1f, lightPosition.y + 0.1f, lightPosition.z - 0.1f, // Light vertex 15

        lightPosition.x + 0.1f, lightPosition.y + 0.1f, lightPosition.z + 0.1f, // Light vertex 16

        lightPosition.x + 0.1f, lightPosition.y - 0.1f, lightPosition.z + 0.1f, // Light vertex 17

        // Triangle 7
        lightPosition.x - 0.1f, lightPosition.y + 0.1f, lightPosition.z - 0.1f, // Light vertex 18

        lightPosition.x - 0.1f, lightPosition.y - 0.1f, lightPosition.z - 0.1f, // Light vertex 19

        lightPosition.x - 0.1f, lightPosition.y - 0.1f, lightPosition.z + 0.1f, // Light vertex 20

        // Triangle 8
        lightPosition.x - 0.1f, lightPosition.y + 0.1f, lightPosition.z - 0.1f, // Light vertex 21

        lightPosition.x - 0.1f, lightPosition.y + 0.1f, lightPosition.z + 0.1f, // Light vertex 22

        lightPosition.x - 0.1f, lightPosition.y - 0.1f, lightPosition.z + 0.1f, // Light vertex 23

        // Triangle 9
        lightPosition.x - 0.1f, lightPosition.y + 0.1f, lightPosition.z - 0.1f, // Light vertex 24

        lightPosition.x + 0.1f, lightPosition.y + 0.1f, lightPosition.z - 0.1f, // Light vertex 25

        lightPosition.x - 0.1f, lightPosition.y - 0.1f, lightPosition.z - 0.1f, // Light vertex 26

        // Triangle 10
        lightPosition.x + 0.1f, lightPosition.y + 0.1f, lightPosition.z - 0.1f, // Light vertex 27

        lightPosition.x + 0.1f, lightPosition.y - 0.1f, lightPosition.z - 0.1f, // Light vertex 28

        lightPosition.x - 0.1f, lightPosition.y - 0.1f, lightPosition.z - 0.1f, // Light vertex 29

        // Triangle 11
        lightPosition.x - 0.1f, lightPosition.y + 0.1f, lightPosition.z + 0.1f, // Light vertex 30

        lightPosition.x - 0.1f, lightPosition.y - 0.1f, lightPosition.z + 0.1f, // Light vertex 31

        lightPosition.x + 0.1f, lightPosition.y - 0.1f, lightPosition.z + 0.1f, // Light vertex 32

        // Triangle 12
        lightPosition.x - 0.1f, lightPosition.y + 0.1f, lightPosition.z + 0.1f, // Light vertex 33

        lightPosition.x + 0.1f, lightPosition.y + 0.1f, lightPosition.z + 0.1f, // Light vertex 34

        lightPosition.x + 0.1f, lightPosition.y - 0.1f, lightPosition.z + 0.1f, // Light vertex 35


        // Light source 2 //

        // Triangle 13
        lightPosition2.x + 0.1f,  lightPosition2.y + 0.1f, lightPosition2.z - 0.1f, // Light vertex 36

        lightPosition2.x + 0.1f,  lightPosition2.y + 0.1f, lightPosition2.z + 0.1f, // Light vertex 37

        lightPosition2.x - 0.1f,  lightPosition2.y + 0.1f, lightPosition2.z + 0.1f, // Light vertex 38

        // Triangle 14
        lightPosition2.x + 0.1f,  lightPosition2.y + 0.1f, lightPosition2.z - 0.1f, // Light vertex 39

        lightPosition2.x - 0.1f,  lightPosition2.y + 0.1f, lightPosition2.z - 0.1f, // Light vertex 40

        lightPosition2.x - 0.1f,  lightPosition2.y + 0.1f, lightPosition2.z + 0.1f, // Light vertex 41

        // Triangle 15
        lightPosition2.x + 0.1f, lightPosition2.y - 0.1f, lightPosition2.z - 0.1f, // Light vertex 42

        lightPosition2.x + 0.1f, lightPosition2.y - 0.1f, lightPosition2.z + 0.1f, // Light vertex 43

        lightPosition2.x - 0.1f, lightPosition2.y - 0.1f, lightPosition2.z + 0.1f, // Light vertex 44

        // Triangle 16
        lightPosition2.x + 0.1f, lightPosition2.y - 0.1f, lightPosition2.z - 0.1f, // Light vertex 45

        lightPosition2.x - 0.1f, lightPosition2.y - 0.1f, lightPosition2.z - 0.1f, // Light vertex 46

        lightPosition2.x - 0.1f, lightPosition2.y - 0.1f, lightPosition2.z + 0.1f, // Light vertex 47

        // Triangle 17
        lightPosition2.x + 0.1f, lightPosition2.y + 0.1f, lightPosition2.z - 0.1f, // Light vertex 48

        lightPosition2.x + 0.1f, lightPosition2.y - 0.1f, lightPosition2.z - 0.1f, // Light vertex 49

        lightPosition2.x + 0.1f, lightPosition2.y - 0.1f, lightPosition2.z + 0.1f, // Light vertex 50

        // Triangle 18 
        lightPosition2.x + 0.1f, lightPosition2.y + 0.1f, lightPosition2.z - 0.1f, // Light vertex 51

        lightPosition2.x + 0.1f, lightPosition2.y + 0.1f, lightPosition2.z + 0.1f, // Light vertex 52

        lightPosition2.x + 0.1f, lightPosition2.y - 0.1f, lightPosition2.z + 0.1f, // Light vertex 53

        // Triangle 19
        lightPosition2.x - 0.1f, lightPosition2.y + 0.1f, lightPosition2.z - 0.1f, // Light vertex 54

        lightPosition2.x - 0.1f, lightPosition2.y - 0.1f, lightPosition2.z - 0.1f, // Light vertex 55

        lightPosition2.x - 0.1f, lightPosition2.y - 0.1f, lightPosition2.z + 0.1f, // Light vertex 56

        // Triangle 20
        lightPosition2.x - 0.1f, lightPosition2.y + 0.1f, lightPosition2.z - 0.1f, // Light vertex 57

        lightPosition2.x - 0.1f, lightPosition2.y + 0.1f, lightPosition2.z + 0.1f, // Light vertex 58

        lightPosition2.x - 0.1f, lightPosition2.y - 0.1f, lightPosition2.z + 0.1f, // Light vertex 59

        // Triangle 21
        lightPosition2.x - 0.1f, lightPosition2.y + 0.1f, lightPosition2.z - 0.1f, // Light vertex 60

        lightPosition2.x + 0.1f, lightPosition2.y + 0.1f, lightPosition2.z - 0.1f, // Light vertex 61

        lightPosition2.x - 0.1f, lightPosition2.y - 0.1f, lightPosition2.z - 0.1f, // Light vertex 62

        // Triangle 22
        lightPosition2.x + 0.1f, lightPosition2.y + 0.1f, lightPosition2.z - 0.1f, // Light vertex 63

        lightPosition2.x + 0.1f, lightPosition2.y - 0.1f, lightPosition2.z - 0.1f, // Light vertex 64

        lightPosition2.x - 0.1f, lightPosition2.y - 0.1f, lightPosition2.z - 0.1f, // Light vertex 65

        // Triangle 23
        lightPosition2.x - 0.1f, lightPosition2.y + 0.1f, lightPosition2.z + 0.1f, // Light vertex 66

        lightPosition2.x - 0.1f, lightPosition2.y - 0.1f, lightPosition2.z + 0.1f, // Light vertex 67

        lightPosition2.x + 0.1f, lightPosition2.y - 0.1f, lightPosition2.z + 0.1f, // Light vertex 68

        // Triangle 24
        lightPosition2.x - 0.1f, lightPosition2.y + 0.1f, lightPosition2.z + 0.1f, // Light vertex 69

        lightPosition2.x + 0.1f, lightPosition2.y + 0.1f, lightPosition2.z + 0.1f, // Light vertex 70

        lightPosition2.x + 0.1f, lightPosition2.y - 0.1f, lightPosition2.z + 0.1f, // Light vertex 71
    };

    // Light source indices
    GLushort indices3[] = {

        // Light source 1 //
        0, 1, 2, // Triangle 1
        3, 4, 5, // Triangle 2
        6, 7, 8, // Triangle 3
        9, 10, 11, // Triangle 4
        12, 13, 14, // Triangle 5
        15, 16, 17, // Triangle 6
        18, 19, 20, // Triangle 7
        21, 22, 23, // Triangle 8
        24, 25, 26, // Triangle 9
        27, 28, 29, // Triangle 10
        30, 31, 32, // Triangle 11
        33, 34, 35, // Triangle 12

        // Light source 2 //
        36 ,37, 38, // Triangle 13
        39, 40, 41, // Triangle 14
        42, 43, 44, // Triangle 15
        45, 46, 47, // Triangle 16
        48, 49, 50, // Triangle 17
        51, 52, 53, // Triangle 18
        54, 55, 56, // Triangle 19
        57, 58, 59, // Triangle 20
        60, 61, 62, // Triangle 21
        63, 64, 65, // Triangle 22
        66, 67, 68, // Triangle 23
        69, 70, 71, // Triangle 24
    };

    // Bowl vertices
    GLfloat verts3[] = {

        // Triangle 1
        -1.375f, 0.3f, 0.375f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.0f, 0.3f, 0.5f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.0f, -0.5f, 0.25f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        // Triangle 2
        - 1.375f, 0.3f, 0.375f,  // Vertex 3
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.0f, -0.5f, 0.25f,  // Vertex 5
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.1875f, -0.5f, 0.1875f,  // Vertex 6
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        // Triangle 3
        -1.0f, 0.3f, 0.5f,  // Vertex 7
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.625f, 0.3f, 0.375f,  // Vertex 8
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.8125f, -0.5f, 0.1875f,  // Vertex 9
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        // Triangle 4
        -1.0f, 0.3f, 0.5f,  // Vertex 10
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.8125f, -0.5f, 0.1875f,  // Vertex 11
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -1.0f, -0.5f, 0.25f,  // Vertex 12
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        // Triangle 5
        -0.625f, 0.3f, 0.375f,  // Vertex 13
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.5f, 0.3f, 0.0f,  // Vertex 14
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.75f, -0.5f, 0.0f,  // Vertex 15
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        // Triangle 6
        -0.625f, 0.3f, 0.375f,  // Vertex 16
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.75f, -0.5f, 0.0f,  // Vertex 17
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.8125f, -0.5f, 0.1875f,  // Vertex 18
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        // Triangle 7
        -0.5f, 0.3f, 0.0f,  // Vertex 19
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.625f, 0.3f, -0.375f,  // Vertex 20
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.8125f, -0.5f, -0.1875f,  // Vertex 21
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        // Triangle 8
        -0.5f, 0.3f, 0.0f,  // Vertex 22
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.8125f, -0.5f, -0.1875f,  // Vertex 23
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.75f, -0.5f, -0.0f,  // Vertex 24
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        // Triangle 9
        -0.625f, 0.3f, -0.375f,  // Vertex 25
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -1.0f, 0.3f, -0.5f,  // Vertex 26
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -1.0f, -0.5f, -0.25f,  // Vertex 27
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        // Triangle 10
        -0.625f, 0.3f, -0.375f,  // Vertex 28
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -1.0f, -0.5f, -0.25f,  // Vertex 29
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.8125f, -0.5f, -0.1875f,  // Vertex 30
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        // Triangle 11
        -1.0f, 0.3f, -0.5f,  // Vertex 31
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.375f, 0.3f, -0.375f,  // Vertex 32
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.1875f, -0.5f, -0.1875f,  // Vertex 33
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        // Triangle 12
        -1.0f, 0.3f, -0.5f,  // Vertex 34
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.1875f, -0.5f, -0.1875f,  // Vertex 35
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.0f, -0.5f, -0.25f,  // Vertex 36
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        // Triangle 13
        -1.375f, 0.3f, -0.375f,  // Vertex 37
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.5f, 0.3f, 0.0f,  // Vertex 38
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.25f, -0.5f, 0.0f,  // Vertex 39
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        // Triangle 14
        -1.375f, 0.3f, -0.375f,  // Vertex 40
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.25f, -0.5f, 0.0f,  // Vertex 41
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.1875f, -0.5f, -0.1875f,  // Vertex 42
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        // Triangle 15
        -1.5f, 0.3f, 0.0f,  // Vertex 43
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.375f, 0.3f, 0.375f,  // Vertex 44
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.25f, -0.5f, 0.0f,  // Vertex 45
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        // Triangle 16
        -1.375f, 0.3f, 0.375f,  // Vertex 46
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.25f, -0.5f, 0.0f,  // Vertex 47
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.1875f, -0.5f, 0.1875f,  // Vertex 48
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        // Triangle 17
        -1.0f, -0.499f, 0.25f,  // Vertex 49
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -0.8125f, -0.499f, 0.1875f,  // Vertex 50
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.0f, -0.499f, 0.0,  // Vertex 51
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 18
        -0.8125f, -0.499f, 0.1875f,  // Vertex 52
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -0.75f, -0.499f, 0.0f,  // Vertex 53
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.0f, -0.499f, 0.0,  // Vertex 54
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 19
        -0.75f, -0.499f, 0.0f,  // Vertex 55
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -0.8125f, -0.499f, -0.1875f,  // Vertex 56
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.0f, -0.499f, 0.0,  // Vertex 57
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 20
        -0.8125f, -0.499f, -0.1875f,  // Vertex 58
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.0f, -0.499f, -0.25f,
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.0f, -0.499f, 0.0,  // Vertex 59
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 21
        -1.0f, -0.499f, -0.25f,  // Vertex 60
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.1875f, -0.499f, -0.1875f,  // Vertex 61
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.0f, -0.499f, 0.0,  // Vertex 62
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 22
        -1.1875f, -0.499f, -0.1875f,  // Vertex 63
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.25f, -0.499f, 0.0f,  // Vertex 64
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.0f, -0.499f, 0.0,  // Vertex 65
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 23
        -1.25f, -0.499f, 0.0f,  // Vertex 66
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.1875f, -0.499f, 0.1875f,  // Vertex 67
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.0f, -0.499f, 0.0,  // Vertex 68
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 24
        -1.1875f, -0.499f, 0.1875f,  // Vertex 69
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.0f, -0.499f, 0.25f,  // Vertex 70
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        -1.0f, -0.499f, 0.0,  // Vertex 71
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y
    };

    // Bowl indices
    GLushort indices4[] = {
        0, 1, 2, // Triangle 1
        3, 4, 5, // Triangle 2
        6, 7, 8, // Triangle 3
        9, 10, 11, // Triangle 4
        12, 13, 14, // Triangle 5
        15, 16, 17, // Triangle 6
        18, 19, 20, // Triangle 7
        21, 22, 23, // Triangle 8
        24, 25, 26, // Triangle 9
        27, 28, 29, // Triangle 10
        30, 31, 32, // Triangle 11
        33, 34, 35, // Triangle 12
        36 ,37, 38, // Triangle 13
        39, 40, 41, // Triangle 14
        42, 43, 44, // Triangle 15
        45, 46, 47, // Triangle 16
        48, 49, 50, // Triangle 17
        51, 52, 53, // Triangle 18
        54, 55, 56, // Triangle 19
        57, 58, 59, // Triangle 20
        60, 61, 62, // Triangle 21
        63, 64, 65, // Triangle 22
        66, 67, 68, // Triangle 23
        69, 70, 71, // Triangle 24
    };

    // Round pumpkin vertices
    GLfloat verts4[] = {

        // Triangle 1
        -1.15f, -0.35f, 0.9375f,  // Vertex 0
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        -1.0f, -0.35f, 1.0f,  // Vertex 1
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        -1.075f, -0.2375f, 0.84375f,  // Vertex 2
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

       // Triangle 2
       -1.0f, -0.35f, 1.0f,  // Vertex 3
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
       -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

       -1.075f, -0.2375f, 0.84375f,  // Vertex 4
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

       -1.0f, -0.2375f, 0.875f,  // Vertex 5
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        // Triangle 3
        -1.0f, -0.35f, 1.0f,  // Vertex 6
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -0.85f, -0.35f, .9375f,  // Vertex 7
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -1.0f, -0.2375f, 0.875f,  // Vertex 8
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        // Triangle 4
        -0.85f, -0.35f, 0.9375f,  // Vertex 9
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -1.0f, -0.2375f, .875f,  // Vertex 10
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -0.875f, -0.2375f, 0.84375f,  // Vertex 11
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        // Triangle 5
        -0.85f, -0.35f, 0.9375f,  // Vertex 12
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -0.8f, -0.35f, 0.75f,  // Vertex 13
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -0.875f, -0.2375f, 0.84375f,  // Vertex 14
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        // Triangle 6
        -0.8f, -0.35f, 0.75f,  // Vertex 15
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -0.875f, -0.2375f, 0.84375f,  // Vertex 16
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -0.9f, -0.2375f, 0.75f,  // Vertex 17
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        // Triangle 7
        -0.8f, -0.35f, 0.75f,  // Vertex 18
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -0.85f, -0.35f, 0.5625f,  // Vertex 19
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -0.9f, -0.2375f, 0.75f,  // Vertex 20
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        // Triangle 8
        -0.85f, -0.35f, 0.5625f,  // Vertex 21
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -0.9f, -0.2375f, 0.75f,  // Vertex 22
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -0.875f, -0.2375f, 0.65625f,  // Vertex 23
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        // Triangle 9
        -0.85f, -0.35f, 0.5625f,  // Vertex 24
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -1.0f, -0.35f, 0.5f,  // Vertex 25
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -0.875f, -0.2375f, 0.65625f,  // Vertex 26
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        // Triangle 10
        -1.0f, -0.35f, 0.5f,  // Vertex 27
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -0.875f, -0.2375f, 0.65625f,  // Vertex 28
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -1.0f, -0.2375f, 0.625f,  // Vertex 29
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        // Triangle 11
        -1.0f, -0.35f, 0.5f,  // Vertex 30
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.15f, -0.35f, 0.5625f,  // Vertex 31
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.0f, -0.2375f, 0.625f,  // Vertex 32
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        // Triangle 12
        -1.15f, -0.35f, 0.5625f,  // Vertex 33
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.0f, -0.2375f, 0.625f,  // Vertex 34
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.075f, -0.2375f, 0.65625f,  // Vertex 35
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        // Triangle 13
        -1.15f, -0.35f, 0.5625f,  // Vertex 36
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.2f, -0.35f, 0.75f,  // Vertex 37
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.075f, -0.2375f, 0.65625f,  // Vertex 38
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        // Triangle 14
        -1.2f, -0.35f, 0.75f,  // Vertex 39
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.075f, -0.2375f, 0.65625f,  // Vertex 40
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.1f, -0.2375f, 0.75f,  // Vertex 41
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        // Triangle 15
        -1.2f, -0.35f, 0.75f,  // Vertex 42
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        -1.15f, -0.35f, 0.9375f,  // Vertex 43
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        -1.1f, -0.2375f, 0.75f,  // Vertex 44
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        // Triangle 16
        -1.15f, -0.35f, 0.9375f,  // Vertex 45
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        -1.1f, -0.2375f, 0.75f,  // Vertex 46
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        -1.075f, -0.2375f, 0.84375f,  // Vertex 47
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        // Triangle 17
        -1.15f, -0.35f, 0.9375f,  // Vertex 48
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.0f, -0.35f, 1.0f,  // Vertex 49
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.075f, -0.4625f, 0.84375f,  // Vertex 50
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        // Triangle 18
        -1.0f, -0.35f, 1.0f,  // Vertex 51
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.075f, -0.4625f, 0.84375f, // Vertex 52
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.0f, -0.4625f, 0.875f,  // Vertex 53
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        // Triangle 19
        -1.0f, -0.35f, 1.0f,  // Vertex 54
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.85f, -0.35f, .9375f,  // Vertex 55
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -1.0f, -0.4625f, 0.875f,  // Vertex 56
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        // Triangle 20
        -0.85f, -0.35f, .9375f,  // Vertex 57
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -1.0f, -0.4625f, 0.875f,  // Vertex 58
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.875f, -0.4625f, 0.84375f,  // Vertex 59
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        // Triangle 21
        -0.85f, -0.35f, 0.9375f,  // Vertex 60
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.8f, -0.35f, 0.75f,  // Vertex 61
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.875f, -0.4625f, 0.84375f,  // Vertex 62
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        // Triangle 22
        -0.8f, -0.35f, 0.75f,  // Vertex 63
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.875f, -0.4625f, 0.84375f,  // Vertex 64
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.9f, -0.4625f, 0.75f,  // Vertex 65
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        // Triangle 23
        -0.8f, -0.35f, 0.75f,  // Vertex 66
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.85f, -0.35f, 0.5625f,  // Vertex 67
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.9f, -0.4625f, 0.75f,  // Vertex 68
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        // Triangle 24
        -0.85f, -0.35f, 0.5625f,  // Vertex 69
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.9f, -0.4625f, 0.75f,   // Vertex 70
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.875f, -0.4625f, 0.65625f,  // Vertex 71
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        // Triangle 25
        -0.85f, -0.35f, 0.5625f,  // Vertex 72
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -1.0f, -0.35f, 0.5f,  // Vertex 73
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.875f, -0.4625f, 0.65625f,  // Vertex 74
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        // Triangle 26
        -1.0f, -0.35f, 0.5f,  // Vertex 75
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.875f, -0.4625f, 0.65625f,  // Vertex 76
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -1.0f, -0.4625f, 0.625f,  // Vertex 77
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        // Triangle 27
        -1.0f, -0.35f, 0.5f,  // Vertex 78
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.15f, -0.35f, 0.5625f,  // Vertex 79
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.0f, -0.4625f, 0.625f,  // Vertex 80
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        // Triangle 28
        -1.15f, -0.35f, 0.5625f,  // Vertex 81
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.0f, -0.4625f, 0.625f,  // Vertex 82
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.075f, -0.4625f, 0.65625f,  // Vertex 83
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        // Triangle 29
        -1.15f, -0.35f, 0.5625f,  // Vertex 84
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.2f, -0.35f, 0.75f,  // Vertex 85
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.075f, -0.4625f, 0.65625f,  // Vertex 86
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        // Triangle 30
        -1.2f, -0.35f, 0.75f,  // Vertex 87
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.075f, -0.4625f, 0.65625f,  // Vertex 88
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.1f, -0.4625f, 0.75f,  // Vertex 89
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        // Triangle 31
        -1.2f, -0.35f, 0.75f,  // Vertex 90
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.15f, -0.35f, 0.9375f,  // Vertex 91
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.1f, -0.4625f, 0.75f,  // Vertex 92
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        // Triangle 32
        -1.15f, -0.35f, 0.9375f,  // Vertex 93
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.1f, -0.4625f, 0.75f,  // Vertex 94
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.075f, -0.4625f, 0.84375f,  // Vertex 95
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

             // Triangle 33
        -1.0755f, -0.2375f, 0.84375f,  // Vertex 96
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        -1.0f, -0.2375f, 0.875f,  // Vertex 97
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        -1.0f, -0.2f, 0.75f,  // Vertex 98
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        // Triangle 34
        -1.0f, -0.2375f, 0.875f,  // Vertex 99
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -0.875f, -0.2375f, .84375f,  // Vertex 100
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -1.0f, -0.2f, 0.75f,  // Vertex 101
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        // Triangle 35
        -0.875f, -0.2375f, 0.84375f,  // Vertex 102
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -0.9f, -0.2375f, 0.75f,  // Vertex 103
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        -1.0f, -0.2f, 0.75f,  // Vertex 104
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, 1.0f, // Normal positive x, positive y, and positive z

        // Triangle 36
        -0.9f, -0.2375f, 0.75f,  // Vertex 105
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -0.875f, -0.2375f, 0.65625f,  // Vertex 106
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -1.0f, -0.2f, 0.75f,  // Vertex 107
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        // Triangle 37
        -0.875f, -0.2375f, 0.65625f,  // Vertex 108
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -1.0f, -0.2375f, 0.625f,  // Vertex 109
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        -1.0f, -0.2f, 0.75f,  // Vertex 110
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 1.0f, -1.0f, // Normal positive x, positive y, and negative z

        // Triangle 38
        -1.0f, -0.2375f, 0.625f,  // Vertex 111
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.075f, -0.2375f, 0.65625f,  // Vertex 112
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.0f, -0.2f, 0.75f,  // Vertex 113
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        // Triangle 39
        -1.1f, -0.2375f, 0.75f,  // Vertex 114
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.075f, -0.2375f, 0.65625f,  // Vertex 115
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        -1.0f, -0.2f, 0.75f,  // Vertex 116
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, 1.0f, -1.0f, // Normal negative x, positive y, and negative z

        // Triangle 40
        -1.1f, -0.2375f, 0.75f,  // Vertex 117
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        -1.075f, -0.2375f, 0.84375f,  // Vertex 118
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

        -1.0f, -0.2f, 0.75f,  // Vertex 119
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, 1.0f, 1.0f, // Normal negative x, positive y, and positive z

             // Triangle 41
        -1.075f, -0.4625f, 0.84375f,  // Vertex 120
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.0f, -0.4625f, 0.875f,  // Vertex 121
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.0f, -0.5f, 0.75f,  // Vertex 122
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        // Triangle 42
        -1.0f, -0.4625f, 0.875f,  // Vertex 123
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.875f, -0.4625f, .84375f,  // Vertex 124
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -1.0f, -0.5f, 0.75f,  // Vertex 125
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        // Triangle 43
        -0.875f, -0.4625f, 0.84375f,  // Vertex 126
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -0.9f, -0.4625f, 0.75f,  // Vertex 127
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        -1.0f, -0.5f, 0.75f,  // Vertex 128
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, 1.0f, // Normal positive x, negative y, and positive z

        // Triangle 44
        -0.9f, -0.4625f, 0.75f,  // Vertex 129
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -0.875f, -0.4625f, 0.65625f,  // Vertex 130
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -1.0f, -0.5f, 0.75f,  // Vertex 131
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        // Triangle 45
        -0.875f, -0.4625f, 0.65625f,  // Vertex 132
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -1.0f, -0.4625f, 0.625f,  // Vertex 133
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        -1.0f, -0.5f, 0.75f,  // Vertex 134
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, -1.0f, -1.0f, // Normal positive x, negative y, and negative z

        // Triangle 46
        -1.0f, -0.4625f, 0.625f,  // Vertex 135
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.075f, -0.4625f, 0.65625f,  // Vertex 136
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.0f, -0.5f, 0.75f,  // Vertex 137
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        // Triangle 47
        -1.075f, -0.4625f, 0.65625f,  // Vertex 138
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.1f, -0.4625f, 0.75f,  // Vertex 139
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        -1.0f, -0.5f, 0.75f,  // Vertex 140
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, -1.0f, // Normal negative x, negative y, and negative z

        // Triangle 48
        -1.1f, -0.4625f, 0.75f,  // Vertex 141
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.075f, -0.4625f, 0.84375f,  // Vertex 142
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z

        -1.0f, -0.5f, 0.75f,  // Vertex 143
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
        -1.0f, -1.0f, 1.0f, // Normal negative x, negative y, and positive z
    };

    // Round pumpkin indices
    GLushort indices5[] = {
        0, 1, 2, // Triangle 1
        3, 4, 5, // Triangle 2
        6, 7, 8, // Triangle 3
        9, 10, 11, // Triangle 4
        12, 13, 14, // Triangle 5
        15, 16, 17, // Triangle 6
        18, 19, 20, // Triangle 7
        21, 22, 23, // Triangle 8
        24, 25, 26, // Triangle 9
        27, 28, 29, // Triangle 10
        30, 31, 32, // Triangle 11
        33, 34, 35, // Triangle 12
        36 ,37, 38, // Triangle 13
        39, 40, 41, // Triangle 14
        42, 43, 44, // Triangle 15
        45, 46, 47, // Triangle 16
        48, 49, 50, // Triangle 17
        51, 52, 53, // Triangle 18
        54, 55, 56, // Triangle 19
        57, 58, 59, // Triangle 20
        60, 61, 62, // Triangle 21
        63, 64, 65, // Triangle 22
        66, 67, 68, // Triangle 23
        69, 70, 71, // Triangle 24
        72, 73, 74, // Triangle 25
        75, 76, 77, // Triangle 26
        78, 79, 80, // Triangle 27
        81, 82, 83, // Triangle 28
        84, 85, 86, // Triangle 29
        87, 88, 89, // Triangle 30
        90, 91, 92, // Triangle 31
        93, 94, 95, // Triangle 32
        96, 97, 98, // Triangle 33
        99, 100, 101, // Triangle 34
        102, 103, 104, // Triangle 35
        105, 106, 107, // Triangle 36
        108, 109, 110, // Triangle 37
        111, 112, 113, // Triangle 38
        114, 115, 116, // Triangle 39
        117, 118, 119, // Triangle 40
        120, 121, 122, // Triangle 41
        123, 124, 125, // Triangle 42
        126, 127, 128, // Triangle 43
        129, 130, 131, // Triangle 44
        132, 133, 134, // Triangle 45
        135, 136, 137, // Triangle 46
        138, 139, 140, // Triangle 47
        141, 142, 143, // Triangle 48
    };

    // Round pumpkin stem vertices
    GLfloat verts5[] = {

       // Triangle 1
       -1.03125f, -0.225f, 0.78125f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 0.0f, 1.0f, // Normal positive z

       -0.96875f, -0.225f, 0.78125f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 0.0f, 1.0f, // Normal positive z

       -1.03125f, -0.125f, 0.78125f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 0.0f, 1.0f, // Normal positive z

       // Triangle 2
       -1.03125f, -0.125f, 0.78125f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       0.0f, 0.0f, 1.0f, // Normal positive z

       -0.96875f, -0.125f, 0.78125f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
       0.0f, 0.0f, 1.0f, // Normal positive z

       -0.96875f, -0.225f, 0.78125f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       0.0f, 0.0f, 1.0f, // Normal positive z

       // Triangle 3
       -0.96875f, -0.225f, 0.78125f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, 0.0f, 0.0f, // Normal positive x

       -0.96875f, -0.225f, 0.71875f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, 0.0f, // Normal positive x

       -0.96875f, -0.125f, 0.78125f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, 0.0f, // Normal positive x

       // Triangle 4
       -0.96875f, -0.125f, 0.78125f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, 0.0f, // Normal positive x

       -0.96875f, -0.125f, 0.71875f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        1.0f, 0.0f, 0.0f, // Normal positive x

       -0.96875f, -0.225f, 0.71875f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, 0.0f, // Normal positive x

       // Triangle 5
       -0.96875f, -0.225f, 0.71875f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

       -1.03125f, -0.225f, 0.71875f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

       -0.96875f, -0.125f, 0.71875f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

       // Triangle 6
       -0.96875f, -0.125f, 0.71875f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

       -1.03125f, -0.125f, 0.71875f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

       -1.03125f, -0.225f, 0.71875f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 0.0f, -1.0f, // Normal negative z

       // Triangle 7
       -1.03125f, -0.225f, 0.71875f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        -1.0f, 0.0f, 0.0f, // Normal negative x

       -1.03125f, -0.225f, 0.78125f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 0.0f, 0.0f, // Normal negative x

       -1.03125f, -0.125f, 0.71875f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, 0.0f, // Normal negative x

       // Triangle 8
       -1.03125f, -0.125f, 0.71875f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, 0.0f, // Normal negative x

       -1.03125f, -0.125f, 0.78125f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
       -1.0f, 0.0f, 0.0f, // Normal negative x

       -1.03125f, -0.225f, 0.78125f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 0.0f, 0.0f, // Normal negative x

       // Triangle 9
       -1.03125f, -0.125f, 0.71875f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

       -1.03125f, -0.125f, 0.78125f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

       -0.96875f, -0.125f, 0.78125f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

       // Triangle 10
       -0.96875f, -0.125f, 0.71875f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

       -0.96875f, -0.125f, 0.78125f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

       -1.03125f, -0.125f, 0.71875f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y
    };

    // Round pumpkin stem indices
    GLushort indices6[] = {
        0, 1, 2, // Triangle 1
        3, 4, 5, // Triangle 2
        6, 7, 8, // Triangle 3
        9, 10, 11, // Triangle 4
        12, 13, 14, // Triangle 5
        15, 16, 17, // Triangle 6
        18, 19, 20, // Triangle 7
        21, 22, 23, // Triangle 8
        24, 25, 26, // Triangle 9
        27, 28, 29, // Triangle 10
    };

    // Wood pumpkin vertices
    GLfloat verts6[] = {

        // Triangle 1
        0.8f, -0.5f, 0.175f,  // Vertex 0
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        0.975f, -0.5f, 0.35f,  // Vertex 1
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        0.8f, 0.5f, 0.175f,  // Vertex 2
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        // Triangle 2
        0.8f, 0.5f, 0.175f,  // Vertex 3
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        0.975f, 0.5f, 0.35f,  // Vertex 4
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        0.975f, -0.5f, 0.35f,  // Vertex 5
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        // Triangle 3
        0.975f, -0.5f, 0.35f,  // Vertex 6
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        1.15f, -0.5f, 0.175f,  // Vertex 7
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        0.975f, 0.5f, 0.35f,  // Vertex 8
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        // Triangle 4
        0.975f, 0.5f, 0.35f,  // Vertex 9
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        1.15f, 0.5f, 0.175f,  // Vertex 10
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        1.15f, -0.5f, 0.175f,  // Vertex 11
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        // Triangle 5
        1.15f, -0.5f, 0.175f,  // Vertex 12
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        1.325f, -0.5f, 0.35f,  // Vertex 13
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        1.15f, 0.5f, 0.175f,  // Vertex 14
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        // Triangle 6
        1.15f, 0.5f, 0.175f,  // Vertex 15
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        1.325f, 0.5f, 0.35f,  // Vertex 16
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        1.325f, -0.5f, 0.35f,  // Vertex 17
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        // Triangle 7
        1.325f, -0.5f, 0.35f,  // Vertex 18
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        1.5f, -0.5f, 0.175f,  // Vertex 19
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        1.325f, 0.5f, 0.35f,  // Vertex 20
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        // Triangle 8
        1.325f, 0.5f, 0.35f,  // Vertex 21
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        1.5f, 0.5f, 0.175f,  // Vertex 22
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        1.5f, -0.5f, 0.175f,  // Vertex 23
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        // Triangle 9
        1.5f, -0.5f, 0.175f,  // Vertex 24
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        1.325f, -0.5f, 0.0f,  // Vertex 25
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        1.5f, 0.5f, 0.175f,  // Vertex 26
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        // Triangle 10
        1.5f, 0.5f, 0.175f,  // Vertex 27
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        1.325f, 0.5f, 0.0f,  // Vertex 28
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        1.325f, -0.5f, 0.0f,  // Vertex 29
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        // Triangle 11
        1.325f, -0.5f, 0.0f,  // Vertex 30
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        1.5f, -0.5f, -0.175f,  // Vertex 31
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        1.325f, 0.5f, 0.0f,  // Vertex 32
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        // Triangle 12
        1.325f, 0.5f, 0.0f,  // Vertex 33
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        1.5f, 0.5f, -0.175f,  // Vertex 34
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        1.5f, -0.5f, -0.175f,  // Vertex 35
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, 1.0f, // Normal positive x, positive z

        // Triangle 13
        1.5f, -0.5f, -0.175f,  // Vertex 36
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        1.325f, -0.5f, -0.35f,  // Vertex 37
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        1.5f, 0.5f, -0.175f,  // Vertex 38
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        // Triangle 14
        1.5f, 0.5f, -0.175f,  // Vertex 39
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        1.325f, 0.5f, -0.35f,  // Vertex 40
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        1.325f, -0.5f, -0.35f,  // Vertex 41
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        // Triangle 15
        1.15f, -0.5f, -0.175f,  // Vertex 42
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        1.325f, -0.5f, -0.35f,  // Vertex 43
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        1.15f, 0.5f, -0.175f,  // Vertex 44
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        // Triangle 16
        1.15f, 0.5f, -0.175f,  // Vertex 45
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        1.325f, 0.5f, -0.35f,  // Vertex 46
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        1.325f, -0.5f, -0.35f,  // Vertex 47
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        // Triangle 17
        0.975f, -0.5f, -0.35f,  // Vertex 48
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        1.15f, -0.5f, -0.175f,  // Vertex 49
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        0.975f, 0.5f, -0.35f,  // Vertex 50
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        // Triangle 18
        0.975f, 0.5f, -0.35f,  // Vertex 51
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        1.15f, 0.5f, -0.175f,  // Vertex 52
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        1.15f, -0.5f, -0.175f,  // Vertex 53
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        1.0f, 0.0f, -1.0f, // Normal positive x, negative z

        // Triangle 19
        0.8f, -0.5f, -0.175f,  // Vertex 54
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        0.975f, -0.5f, -0.35f,  // Vertex 55
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        0.8f, 0.5f, -0.175f,  // Vertex 56
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        // Triangle 20
        0.8f, 0.5f, -0.175f,  // Vertex 57
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        0.975f, 0.5f, -0.35f,  // Vertex 58
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        0.975f, -0.5f, -0.35f,  // Vertex 59
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        // Triangle 21
        0.8f, -0.5f, -0.175f,  // Vertex 60
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
       -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        0.975f, -0.5f, 0.0f,  // Vertex 61
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        0.8f, 0.5f, -0.175f,  // Vertex 62
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        // Triangle 22
        0.8f, 0.5f, -0.175f,  // Vertex 63
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        0.975f, 0.5f, 0.0f,  // Vertex 64
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
       -1.0f, 0.0f, 1.0f, // Normal negative x, positive z

        0.975f, -0.5f, 0.0f,  // Vertex 65
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 0.0f, 1.0f, // Normal negative x, positive z
    
        // Triangle 23
        0.8f, -0.5f, 0.175f,  // Vertex 66
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        0.975f, -0.5f, 0.0f,  // Vertex 67
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        0.8f, 0.5f, 0.175f,  // Vertex 68
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        // Triangle 24
        0.8f, 0.5f, 0.175f,  // Vertex 69
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        0.975f, 0.5f, 0.0f,  // Vertex 70
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        0.975f, -0.5f, 0.0f,  // Vertex 71
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
       -1.0f, 0.0f, -1.0f, // Normal negative x, negative z

        // Triangle 25
        0.975f, 0.5f, 0.35f,  // Vertex 72
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.15f, 0.5f, 0.175f,  // Vertex 73
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        0.8f, 0.5f, 0.175f,  // Vertex 74
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 26
        0.8f, 0.5f, 0.175f,  // Vertex 75
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        0.975f, 0.5f, 0.0f,  // Vertex 76
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.15f, 0.5f, 0.175f,  // Vertex 77
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 27
        1.15f, 0.5f, 0.175f,  // Vertex 78
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.325f, 0.5f, 0.35f,  // Vertex 79
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.325f, 0.5f, 0.0f,  // Vertex 80
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 28
        1.325f, 0.5f, 0.0f,  // Vertex 81
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.5f, 0.5f, 0.175f,  // Vertex 82
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.325f, 0.5f, 0.35f,  // Vertex 83
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 29
        1.15f, 0.5f, -0.175f,  // Vertex 84
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.325f, 0.5f, 0.0f,  // Vertex 85
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.325f, 0.5f, -0.35f,  // Vertex 86
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 30
        1.325f, 0.5f, -0.35f,  // Vertex 87
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.5f, 0.5f, -0.175f,  // Vertex 88
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.325f, 0.5f, 0.0f,  // Vertex 89
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 31
        0.8f, 0.5f, -0.175f,  // Vertex 90
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        0.975f, 0.5f, 0.0f,  // Vertex 91
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        0.975f, 0.5f, -0.35f,  // Vertex 92
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 32
        0.975f, 0.5f, -0.35f,  // Vertex 93
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.15f, 0.5f, -0.175f,  // Vertex 94
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        0.975f, 0.5f, 0.0f,  // Vertex 95
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 33
        0.975f, 0.5f, 0.0f,  // Vertex 96
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.15f, 0.5f, 0.175f,  // Vertex 97
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.15f, 0.5f, -0.175f,  // Vertex 98
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        // Triangle 34
        1.15f, 0.5f, -0.175f,  // Vertex 99
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        0.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.325f, 0.5f, 0.0f,  // Vertex 100
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 1.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y

        1.15f, 0.5f, 0.175f,  // Vertex 101
        1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
        1.0f, 0.0f, // UV
        0.0f, 1.0f, 0.0f, // Normal positive y
     };

     // Wood pumpkin indices
     GLushort indices7[] = {
        0, 1, 2, // Triangle 1
        3, 4, 5, // Triangle 2
        6, 7, 8, // Triangle 3
        9, 10, 11, // Triangle 4
        12, 13, 14, // Triangle 5
        15, 16, 17, // Triangle 6
        18, 19, 20, // Triangle 7
        21, 22, 23, // Triangle 8
        24, 25, 26, // Triangle 9
        27, 28, 29, // Triangle 10
        30, 31, 32, // Triangle 11
        33, 34, 35, // Triangle 12
        36 ,37, 38, // Triangle 13
        39, 40, 41, // Triangle 14
        42, 43, 44, // Triangle 15
        45, 46, 47, // Triangle 16
        48, 49, 50, // Triangle 17
        51, 52, 53, // Triangle 18
        54, 55, 56, // Triangle 19
        57, 58, 59, // Triangle 20
        60, 61, 62, // Triangle 21
        63, 64, 65, // Triangle 22
        66, 67, 68, // Triangle 23
        69, 70, 71, // Triangle 24
        72, 73, 74, // Triangle 25
        75, 76, 77, // Triangle 26
        78, 79, 80, // Triangle 27
        81, 82, 83, // Triangle 28
        84, 85, 86, // Triangle 29
        87, 88, 89, // Triangle 30
        90, 91, 92, // Triangle 31
        93, 94, 95, // Triangle 32
        96, 97, 98, // Triangle 33
        99, 100, 101, // Triangle 34
      };

     // Wood pumpkin stem vertices
     GLfloat verts7[] = {

         // Triangle 1
         1.10625f, 0.5f, -0.04375f,  // Vertex 0
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         -1.0f, 0.0f, 0.0f, // Normal negative x

         1.10625f, 0.5f, 0.04375f,  // Vertex 1
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         -1.0f, 0.0f, 0.0f, // Normal negative x

         1.10625f, 0.675f, -0.04375f,  // Vertex 2
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         -1.0f, 0.0f, 0.0f, // Normal negative x

         // Triangle 2
         1.10625f, 0.675f, -0.04375f,  // Vertex 3
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         -1.0f, 0.0f, 0.0f, // Normal negative x

         1.10625f, 0.675f, 0.04375f,  // Vertex 4
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 1.0f, // UV
         -1.0f, 0.0f, 0.0f, // Normal negative x

         1.10625f, 0.5f, 0.04375f,  // Vertex 5
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         -1.0f, 0.0f, 0.0f, // Normal negative x

         // Triangle 3
         1.10625f, 0.5f, 0.04375f,  // Vertex 6
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         0.0f, 0.0f, 1.0f, // Normal positive z

         1.19375f, 0.5f, 0.04375f,  // Vertex 7
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         0.0f, 0.0f, 1.0f, // Normal positive z

         1.10625f, 0.675f, 0.04375f,  // Vertex 8
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         0.0f, 0.0f, 1.0f, // Normal positive z

         // Triangle 4
         1.10625f, 0.675f, 0.04375f,  // Vertex 9
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         0.0f, 0.0f, 1.0f, // Normal positive z

         1.19375f, 0.675f, 0.04375f,  // Vertex 10
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 1.0f, // UV
         0.0f, 0.0f, 1.0f, // Normal positive z

         1.19375f, 0.5f, 0.04375f,  // Vertex 11
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         0.0f, 0.0f, 1.0f, // Normal positive z

         // Triangle 5
         1.19375f, 0.5f, -0.04375f,  // Vertex 12
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         1.0f, 0.0f, 0.0f, // Normal positive x

         1.19375f, 0.5f, 0.04375f,  // Vertex 13
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 0.0f, 0.0f, // Normal positive x

         1.19375f, 0.675f, -0.04375f,  // Vertex 14
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 0.0f, 0.0f, // Normal positive x

         // Triangle 6
         1.19375f, 0.675f, -0.04375f,  // Vertex 15
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         1.0f, 0.0f, 0.0f, // Normal positive x

         1.19375f, 0.675f, 0.04375f,  // Vertex 16
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 1.0f, // UV
         1.0f, 0.0f, 0.0f, // Normal positive x

         1.19375f, 0.5f, 0.04375f,  // Vertex 17
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         1.0f, 0.0f, 0.0f, // Normal positive x

         // Triangle 7
         1.10625f, 0.5f, -0.04375f,  // Vertex 18
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         0.0f, 0.0f, -1.0f, // Normal negative z

         1.19375f, 0.5f, -0.04375f,  // Vertex 19
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         0.0f, 0.0f, -1.0f, // Normal negative z

         1.10625f, 0.675f, -0.04375f,  // Vertex 20
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         0.0f, 0.0f, -1.0f, // Normal negative z

         // Triangle 8
         1.10625f, 0.675f, -0.04375f,  // Vertex 21
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         0.0f, 0.0f, -1.0f, // Normal negative z

         1.19375f, 0.675f, -0.04375f,  // Vertex 22
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 1.0f, // UV
         0.0f, 0.0f, -1.0f, // Normal negative z

         1.19375f, 0.5f, -0.04375f,  // Vertex 23
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         0.0f, 0.0f, -1.0f, // Normal negative z

         // Triangle 9
         1.10625f, 0.675f, -0.04375f,  // Vertex 24
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 0.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y

         1.10625f, 0.675f, 0.04375f,  // Vertex 25
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y

         1.19375f, 0.675f, -0.04375f,  // Vertex 26
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y

         // Triangle 10
         1.19375f, 0.675f, -0.04375f,  // Vertex 27
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         0.0f, 1.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y

         1.193755f, 0.675f, 0.04375f,  // Vertex 28
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 1.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y

         1.10625f, 0.675f, 0.04375f,  // Vertex 29
         1.0f, 0.0f, 0.0f, 1.0f, // Colors (r,g,b,a)
         1.0f, 0.0f, // UV
         0.0f, 1.0f, 0.0f, // Normal positive y
     };

     // Wood pumpkin stem indices
     GLushort indices8[] = {
        0, 1, 2, // Triangle 1
        3, 4, 5, // Triangle 2
        6, 7, 8, // Triangle 3
        9, 10, 11, // Triangle 4
        12, 13, 14, // Triangle 5
        15, 16, 17, // Triangle 6
        18, 19, 20, // Triangle 7
        21, 22, 23, // Triangle 8
        24, 25, 26, // Triangle 9
        27, 28, 29, // Triangle 10
     };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUv = 2;
    const GLuint floatsPerNormal = 3;

    // Glasses case information//
    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a, s, t, normalx, normaly, normalz). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor + floatsPerUv + floatsPerNormal);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUv, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor + floatsPerUv)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

    // Table information//
    glGenVertexArrays(1, &mesh2.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh2.vao);

    glGenBuffers(2, mesh2.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh2.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh2.nIndices = sizeof(indices2) / sizeof(indices2[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh2.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices2), indices2, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUv, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor + floatsPerUv)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

    // Lights //
    glGenVertexArrays(1, &mesh3.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh3.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh3.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh3.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts2), verts2, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh3.nIndices = sizeof(indices3) / sizeof(indices3[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh3.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices3), indices3, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z). A tightly packed stride is 0.
    GLint stride2 = sizeof(float) * (floatsPerVertex);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride2, 0);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

    // Bowl Object //
    glGenVertexArrays(1, &mesh4.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh4.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh4.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh4.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts3), verts3, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh4.nIndices = sizeof(indices4) / sizeof(indices4[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh4.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices4), indices4, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUv, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor + floatsPerUv)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

    // Round Pumpkin Object //
    glGenVertexArrays(1, &mesh5.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh5.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh5.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh5.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts4), verts4, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh5.nIndices = sizeof(indices5) / sizeof(indices5[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh5.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices5), indices5, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUv, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor + floatsPerUv)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

    // round pumpkin Stem Object //
    glGenVertexArrays(1, &mesh6.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh6.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh6.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh6.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts5), verts5, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh6.nIndices = sizeof(indices6) / sizeof(indices6[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh6.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices6), indices6, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUv, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor + floatsPerUv)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

    // Wood Pumpkin Object //
    glGenVertexArrays(1, &mesh7.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh7.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh7.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh7.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts6), verts6, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh7.nIndices = sizeof(indices7) / sizeof(indices7[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh7.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices7), indices7, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUv, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor + floatsPerUv)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

    // Wood Pumpkin Stem Object //
    glGenVertexArrays(1, &mesh8.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh8.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh8.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh8.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts7), verts7, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh8.nIndices = sizeof(indices8) / sizeof(indices8[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh8.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices8), indices8, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUv, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(3, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* (floatsPerVertex + floatsPerColor + floatsPerUv)));
    glEnableVertexAttribArray(3);

    glBindVertexArray(0); // Unbind VOA or close off (Must call VOA explicitly in loop)

    // load glasses case texture
    int caseTexWidth, caseTexHeight;
    unsigned char* caseImage = SOIL_load_image("Case_Color.jpg", &caseTexWidth, &caseTexHeight, 0, SOIL_LOAD_RGB);

    // generate glasses case texture
    glGenTextures(1, &caseTexture);
    glBindTexture(GL_TEXTURE_2D, caseTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, caseTexWidth, caseTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, caseImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(caseImage);
    glBindTexture(GL_TEXTURE_2D, 0);


    // load bowl texture
    int bowlTexWidth, bowlTexHeight;
    unsigned char* bowlImage = SOIL_load_image("Bowl_Texture.jpg", &bowlTexWidth, &bowlTexHeight, 0, SOIL_LOAD_RGB);

    // generate bowl texture
    glGenTextures(1, &bowlTexture);
    glBindTexture(GL_TEXTURE_2D, bowlTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, bowlTexWidth, bowlTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, bowlImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(bowlImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    // load table texture
    int tableTexWidth, tableTexHeight;
    unsigned char* tableImage = SOIL_load_image("Table_Texture.jpg", &tableTexWidth, &tableTexHeight, 0, SOIL_LOAD_RGB);

    // generate table texture
    glGenTextures(1, &tableTexture);
    glBindTexture(GL_TEXTURE_2D, tableTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tableTexWidth, tableTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, tableImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(tableImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    // load round pumpkin texture
    int roundPumpkinTexWidth, roundPumpkinTexHeight;
    unsigned char* roundPumpkinImage = SOIL_load_image("Round_Pumpkin_Texture.jpg", &roundPumpkinTexWidth, &roundPumpkinTexHeight, 0, SOIL_LOAD_RGB);

    // generate round pumpkin texture
    glGenTextures(1, &roundPumpkinTexture);
    glBindTexture(GL_TEXTURE_2D, roundPumpkinTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, roundPumpkinTexWidth, roundPumpkinTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, roundPumpkinImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(roundPumpkinImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    // load pumpkin stem texture
    int pumpkinStemTexWidth, pumpkinStemTexHeight;
    unsigned char* pumpkinStemImage = SOIL_load_image("Pumpkin_Stem.jpg", &pumpkinStemTexWidth, &pumpkinStemTexHeight, 0, SOIL_LOAD_RGB);

    // generate round pumpkin texture
    glGenTextures(1, &pumpkinStemTexture);
    glBindTexture(GL_TEXTURE_2D, pumpkinStemTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, pumpkinStemTexWidth, pumpkinStemTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, pumpkinStemImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(pumpkinStemImage);
    glBindTexture(GL_TEXTURE_2D, 0);

    // load wood pumpkin texture
    int woodPumpkinTexWidth, woodPumpkinTexHeight;
    unsigned char* woodPumpkinImage = SOIL_load_image("Wood_Pumpkin_Texture.jpg", &woodPumpkinTexWidth, &woodPumpkinTexHeight, 0, SOIL_LOAD_RGB);

    // generate wood pumpkin texture
    glGenTextures(1, &woodPumpkinTexture);
    glBindTexture(GL_TEXTURE_2D, woodPumpkinTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, woodPumpkinTexWidth, woodPumpkinTexHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, woodPumpkinImage);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(woodPumpkinImage);
    glBindTexture(GL_TEXTURE_2D, 0);
}


void UDestroyMesh(GLMesh& mesh, GLMesh& mesh2, GLMesh& mesh3, GLMesh& mesh4, GLMesh& mesh5, GLMesh& mesh6, GLMesh& mesh7, GLMesh& mesh8)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);

    glDeleteVertexArrays(1, &mesh2.vao);
    glDeleteBuffers(2, mesh2.vbos);

    glDeleteVertexArrays(1, &mesh3.vao);
    glDeleteBuffers(2, mesh3.vbos);

    glDeleteVertexArrays(1, &mesh4.vao);
    glDeleteBuffers(2, mesh4.vbos);

    glDeleteVertexArrays(1, &mesh5.vao);
    glDeleteBuffers(2, mesh5.vbos);

    glDeleteVertexArrays(1, &mesh6.vao);
    glDeleteBuffers(2, mesh6.vbos);

    glDeleteVertexArrays(1, &mesh7.vao);
    glDeleteBuffers(2, mesh7.vbos);

    glDeleteVertexArrays(1, &mesh8.vao);
    glDeleteBuffers(2, mesh8.vbos);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}